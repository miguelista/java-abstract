public class canil {
    public static void main(String args[]){
        cachorro p1 = new cachorro();
        p1.altura = 30;
        p1.comprimento = 40;
        p1.patas = 4;
        p1.peso = 15.7    ;
        //----------------

        p1.comportamento();
        p1.som();
        p1.dormir();
    }


}
