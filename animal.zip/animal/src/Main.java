// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public abstract class Main {
    float altura;
    int patas;
    float comprimento;
    double peso;

    public abstract void comportamento();

    public abstract void dormir();

    public abstract void som();


    public void setPeso(float peso) {
        this.peso = peso;
    }
}