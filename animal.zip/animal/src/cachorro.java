public class cachorro extends Main {

    @Override
    public void comportamento() {
        System.out.println("O cachorro é manso");

    }

    @Override
    public void som() {
        System.out.println("O cachorro diz 'au au!'");
    }

    @Override
    public void dormir() {
        System.out.println("O cachorro dorme estirado");


    }
}
