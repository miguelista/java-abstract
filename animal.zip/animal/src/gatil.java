public class gatil {
        public static void main(String args[]){
            gato_de_rua n1 = new gato_de_rua();
            n1.altura = 20;
            n1.comprimento = 30;
            n1.patas = 4;
            n1.peso = 5.5;
            //----------------
            n1.comportamento();
            n1.som();
            n1.dormir();
        }


    }
