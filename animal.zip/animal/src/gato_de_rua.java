
public class gato_de_rua extends Main {
    @Override
    public void comportamento() {
        System.out.println("O gato não é manso");

    }

    @Override
    public void dormir() {
        System.out.println("O gato dorme encolhido");

    }

    @Override
    public void som() {
        System.out.println("O gato diz 'miau!'");


    }
}